class employee{
    String empname;
    float salary;
    void displayEmployee(){
        System.out.println("emp name is "+empname+ "salary is "+salary);
    }
}
class manager extends employee{
    float bonus;
    void displaySalary(){
        float total=salary+bonus;
        System.out.println("total slary is "+total);
    }
}
public class Inheritance6 {
    public static void main(String[] args) {
        manager m=new manager();
        m.empname="hindu";
        m.salary=80000;
        m.bonus=5000;
        m.displayEmployee();
        m.displaySalary();
    }
}
