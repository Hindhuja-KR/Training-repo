class person{
    String name;
    int age;
    void display(){
        System.out.println("name is "+name+" age is "+age);
    }
}
class student extends person{
    int rollno;
    void displayStudent(){
        super.display();
        System.out.println("roll no is "+rollno);
    }
}

public class Inheritance8 {
    public static void main(String[] args) {
        student s=new student();
        s.name="hindhu";
        s.age=20;
        s.rollno=101;
        s.displayStudent();
    }
}
