class Person {
    void displayPerson() {
        System.out.println("Person detail");
    }
}

class Employee extends Person {
    void displayEmployee() {
        System.out.println("Employee details");
    }
}
class Manager extends Employee {
    void displayManager() {
        System.out.println("Manager details");
    }
}
public class Inheritance4{
    public static void main(String[] args) {
        Manager m = new Manager();
        m.displayPerson();
        m.displayEmployee();
        m.displayManager();
    }
}