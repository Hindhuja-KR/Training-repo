class employee{
    String name;
    int salary;
    void displayEmployee(){
        System.out.println("name is "+name+"slary is "+salary);
    }
}
class developer extends employee{
    String pgmlang;
    void displayDeveloper(){
        System.out.println("programming language is "+pgmlang);
    }
}
class seniordev extends developer{
    int exp;
    void displaySen(){
        System.out.println("experience is "+exp);
    }
}

public class Inheritance11 {
    public static void main(String[] args) {
        seniordev s=new seniordev();
        s.name="hindhu";
        s.salary=80000;
        s.pgmlang="java";
        s.exp=3;
        s.displayEmployee();
        s.displayDeveloper();
        s.displaySen();
    }
}
