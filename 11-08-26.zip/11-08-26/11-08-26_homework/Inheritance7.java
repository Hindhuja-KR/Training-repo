class Animal{
    void sound(){
        System.out.println("sound of animal");
    }
}
class dog extends Animal{
    void sound(){
        System.out.println("dog barks");
    }
}
class cat extends Animal{
    void sound(){
        System.out.println("cat meows");
    }
}
public class Inheritance7 {
    public static void main(String[] args) {
        dog d=new dog();
        d.sound();
        cat c=new cat();
        c.sound();
    }
}
