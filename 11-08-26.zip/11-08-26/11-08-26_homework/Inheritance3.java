
class calculator{
    void add(int a , int b){
        System.out.println("add:"+(a+b));
    }
    void sub(int a , int b){
        System.out.println("sub :"+(a-b));
    }
}
class advancecalculator extends calculator{
    void multiply(int a , int b){
        System.out.println("multiply:"+(a*b));
    }
    void divide(int a, int b){
        System.out.println("divide:"+(a/b));
    }
}
public class Inheritance3 {
    public static void main(String [] args){
        advancecalculator t =new advancecalculator();
        t.add(10,20);
        t.sub(20,10);
        t.multiply(4,4);
        t.divide(4,2);
    }
}
