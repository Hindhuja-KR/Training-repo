class vehicle{
    void start(){
        System.out.println("vehicle starting");
    }
}
class car extends vehicle{
    void startcar(){
        System.out.println("car starting");
    }
}
class evcar extends car{
    void startev(){
        System.out.println("ev car starts by motor");
    }
}
public class Multilvlinh {
    public static void main(String[] args){
        evcar e=new evcar();
        e.start();
        e.startcar();
        e.startev();
    }
}
