public class Staticeg{
    static {
        System.out.println("i am static");
    }
    public static void main(String[] args){

    }
}