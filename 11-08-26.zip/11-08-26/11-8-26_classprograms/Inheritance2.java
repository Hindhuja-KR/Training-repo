class person{
    String name="hindhu";
    int age=19;
    void displayPerson(){
        System.out.println("name is "+name + " age is "+ age);
    }
}
class employee extends person{
    int employeeid=101;
    void displayEmployee(){
        System.out.println("employee id is "+ employeeid);
    }
}

public class Inheritance2 {
    public static void main(String[] args) {
        employee e=new employee();
        e.displayPerson();
        e.displayEmployee();
    }
}
