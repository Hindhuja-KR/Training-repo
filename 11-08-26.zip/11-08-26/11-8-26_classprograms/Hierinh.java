class vehicle{
    void start(){
        System.out.println("vehicle is starting");
    }
}
class car extends vehicle{
    void startcar(){
        System.out.println("car starting");
    }
}
class truck extends vehicle{
    void starttruck(){
        System.out.println("truck starting");
    }
}

public class Hierinh {
    public static void main(String [] args){
        car c=new car();
        c.startcar();
        
        truck t=new truck();
        t.starttruck();
    }
}
