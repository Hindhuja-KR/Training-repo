public class Constructorchain{
    int a;
    Constructorchain(){
        this(1);
        System.out.println("default constructor");
    }
    Constructorchain(int a){
        System.out.println(a);
    }
    public static void main(String[] args){
        Constructorchain c= new Constructorchain();
    }
}