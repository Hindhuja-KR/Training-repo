import java.util.*;
public class Rotatearrusecoll
{
	public static void main(String[] args) {
	    
		List<Integer> num = new ArrayList<>();
		num.add(10);
		num.add(20);
		num.add(30);
		num.add(40);
		num.add(50);
		int k=2;
		for(int i=0;i<k;i++)
		{
		    int last = num.remove(num.size()-1);
		    num.add(0,last);
		}
		System.out.println("Rotated list : "+ num);
		
	}
}