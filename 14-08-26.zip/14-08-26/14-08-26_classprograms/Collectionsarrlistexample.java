import java.util.*;
public class Collectionsarrlistexample
{
	public static void main(String[] args) {
	    
		List<String> name = new LinkedList<>();
		name.add("Vasanth");
		name.add("Priyan");
		name.add("Aaghash");
		name.add("Prathap");
		System.out.println(name);
		System.out.println(name.get(0));
		System.out.println(name.set(1,"vijay"));
		System.out.println(name);
		System.out.println(name.remove(2));
		System.out.println(name);
		System.out.println(name.size());
		System.out.println(name.contains("Prathap"));
	}
}