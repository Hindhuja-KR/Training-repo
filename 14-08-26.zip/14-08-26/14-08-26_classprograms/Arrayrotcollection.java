import java.util.*;
public class Arrayrotcollection
{
	public static void main(String[] args) {
		List<Integer> num = new ArrayList<>();
		Scanner sc =new Scanner(System.in);
		System.out.println("enter no of elements:");
		int n=sc.nextInt();
		for(int i=0;i<n;i++){
			num.add(sc.nextInt());
		}
		System.out.println("enter no of times rotation:");
		int k=sc.nextInt();
		for(int i=0;i<k;i++)
		{
		    int last = num.remove(num.size()-1);
		    num.add(0,last);
		}
		System.out.println("Rotated list : "+ num);
		// collections.rotate() method exists
		// collections.sort(list,-k);
		// collections.sort(list,+k);
	}
}