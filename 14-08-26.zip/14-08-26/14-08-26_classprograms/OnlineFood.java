import java.util.*;
interface FoodOrderService{
    double calculateFoodCost();
    double calculateDeliveryCharge();
    double calculateFinalBill();
    void displayOrderDetails();
}
abstract class FoodOrder implements FoodOrderService{
    private int orderId;
    private String customerName;
    private String foodName;
    private double price;
    private int quantity;
    FoodOrder(int orderId,String customerName,String foodName,double price,int quantity){
        this.orderId=orderId;
        this.customerName=customerName;
        this.foodName=foodName;
        this.price=price;
        this.quantity=quantity;
    }
    int getorderId(){
        return orderId;
    }
    String getcustomerName(){
        return customerName;
    }
    String getfoodName(){
        return foodName;
    }
    double getprice(){
        return price;
    }
    int getquantity(){
        return quantity;
    }
    public double calculateFoodCost(){
        return price*quantity;
    }
    public double calculateFinalBill(){
        return calculateFoodCost()+calculateDeliveryCharge();
    }
    public void displayOrderDetails(){
        System.out.println("order id:"+orderId);
        System.out.println("customer name:"+customerName);
        System.out.println("food name:"+foodName);
        System.out.println("quantity:"+quantity);
        System.out.println("food cost:"+calculateFoodCost());
        System.out.println("delivery charge:"+calculateDeliveryCharge());
        System.out.println("final bill:"+calculateFinalBill());
    }
}

class RegularOrder extends FoodOrder{
    RegularOrder(int orderId,String customerName,String foodName,double price,int quantity){
        super(orderId,customerName,foodName,price,quantity);
    }
    public double calculateDeliveryCharge(){
        return 40;
    }
}
class ExpressOrder extends FoodOrder{
    ExpressOrder(int orderId,String customerName,String foodName,double price,int quantity){
        super(orderId,customerName,foodName,price,quantity);
    }
    public double calculateDeliveryCharge(){
        return 80;
    }
}
class PremiumOrder extends FoodOrder{
    PremiumOrder(int orderId,String customerName,String foodName,double price,int quantity){
        super(orderId,customerName,foodName,price,quantity);
    }
    public double calculateDeliveryCharge(){
        return 0;
    }
}
public class OnlineFood{
    public static void main(String[] args){
        ArrayList<FoodOrder> orders=new ArrayList<>();
        FoodOrder f;
        f=new RegularOrder(101,"anu","biryani",250,2);
        orders.add(f);
        f=new ExpressOrder(102,"ravi","pizza",500,1);
        orders.add(f);
        f=new PremiumOrder(103,"kumar","burger",200,3);
        orders.add(f);
        System.out.println("all orders");
        for(FoodOrder order:orders){
            order.displayOrderDetails();
            System.out.println();
        }
        System.out.println("search order");
        int searchid=102;
        boolean found=false;
        for(FoodOrder order:orders){
            if(order.getorderId()==searchid){
                order.displayOrderDetails();
                found=true;
                break;
            }
        }
        if(!found){
            System.out.println("order not found");
        }
        System.out.println();
        System.out.println("remove order");
        int removeid=101;
        for(int i=0;i<orders.size();i++){
            if(orders.get(i).getorderId()==removeid){
                orders.remove(i);
                System.out.println("order removed");
                break;
            }
        }
        System.out.println();
        System.out.println("orders after removing");
        for(FoodOrder order:orders){
            order.displayOrderDetails();
            System.out.println();
        }
    }
}