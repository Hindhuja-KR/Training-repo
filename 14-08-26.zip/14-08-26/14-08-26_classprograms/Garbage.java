
public class Garbage

{
	public static void main(String[] args) {
	    
		System.out.println("Start");
		String str = new String("Vasanth");
		str = null;
		System.gc();
		System.exit(1);
		System.out.println("End");
	}
}