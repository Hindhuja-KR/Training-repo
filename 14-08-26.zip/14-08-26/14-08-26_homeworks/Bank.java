import java.util.*;

class invalidamount extends Exception{
    invalidamount(String msg){
        super(msg);
    }
}

abstract class bankaccount{
    private int accountnumber;
    private String accountholdername;
    private double balance;

    bankaccount(int accountnumber,String accountholdername,double balance){
        this.accountnumber=accountnumber;
        this.accountholdername=accountholdername;
        this.balance=balance;
    }

    int getaccountnumber(){
        return accountnumber;
    }
    String getaccountholdername(){
        return accountholdername;
    }
    double getbalance(){
        return balance;
    }

    void deposit(double amount)throws invalidamount{
        if(amount<=0){
            throw new invalidamount("invalid deposit amount");
        }
        balance=balance+amount;
        System.out.println("amount deposited:"+amount);
    }

    void reducebalance(double amount){
        balance=balance-amount;
    }

    abstract void withdraw(double amount)throws invalidamount;
}

class savingsaccount extends bankaccount{
    savingsaccount(int accountnumber,String accountholdername,double balance){
        super(accountnumber,accountholdername,balance);
    }

    void withdraw(double amount)throws invalidamount{
        if(amount<=0){
            throw new invalidamount("invalid withdrawal amount");
        }
        if(amount>getbalance()){
            throw new invalidamount("insufficient balance");
        }
        reducebalance(amount);
        System.out.println("withdrawal successful");
    }
}

class currentaccount extends bankaccount{
    currentaccount(int accountnumber,String accountholdername,double balance){
        super(accountnumber,accountholdername,balance);
    }

    void withdraw(double amount)throws invalidamount{
        if(amount<=0){
            throw new invalidamount("invalid withdrawal amount");
        }
        if(getbalance()-amount<1000){
            throw new invalidamount("minimum balance should be maintained");
        }
        reducebalance(amount);
        System.out.println("withdrawal successful");
    }
}

public class Bank{
    public static void main(String[] args){
        bankaccount b;

        try{
            b=new savingsaccount(101,"anu",10000);
            b.deposit(2000);
            b.withdraw(3000);
            System.out.println("savings balance:"+b.getbalance());

            System.out.println();

            b=new currentaccount(102,"ravi",15000);
            b.deposit(2000);
            b.withdraw(5000);
            System.out.println("current balance:"+b.getbalance());

            b.withdraw(12000);
        }
        catch(invalidamount e){
            System.out.println(e.getMessage());
        }
        finally{
            System.out.println("bank transaction completed.");
        }
    }
}