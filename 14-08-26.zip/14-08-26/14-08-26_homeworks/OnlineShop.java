class invalidprice extends Exception{
    invalidprice(String msg){
        super(msg);
    }
}
abstract class product{
    private int productid;
    private String productname;
    private double price;
    product(int productid,String productname,double price)throws invalidprice{
        if(price<=0){
            throw new invalidprice("invalid product price");
        }
        this.productid=productid;
        this.productname=productname;
        this.price=price;
    }
    int getproductid(){
        return productid;
    }
    String getproductname(){
        return productname;
    }
    double getprice(){
        return price;
    }
    abstract double calculatediscount();

    double calculatefinalprice(){
        return price-calculatediscount();
    }
    void displaydetails(){
        System.out.println("product id:"+productid);
        System.out.println("product name:"+productname);
        System.out.println("original price:"+price);
        System.out.println("discount:"+calculatediscount());
        System.out.println("final price:"+calculatefinalprice());
    }
}
class electronics extends product{
    electronics(int productid,String productname,double price)throws invalidprice{
        super(productid,productname,price);
    }
    double calculatediscount(){
        return getprice()*10/100;
    }
}
class clothing extends product{
    clothing(int productid,String productname,double price)throws invalidprice{
        super(productid,productname,price);
    }
    double calculatediscount(){
        return getprice()*20/100;
    }
}
class grocery extends product{
    grocery(int productid,String productname,double price)throws invalidprice{
        super(productid,productname,price);
    }
    double calculatediscount(){
        return getprice()*5/100;
    }
}
public class OnlineShop{
    public static void main(String[] args){
        product p;
        try{
            p=new electronics(101,"laptop",50000);
            p.displaydetails();
            p=new clothing(102,"shirt",2000);
            p.displaydetails();
            p=new grocery(103,"rice",1000);
            p.displaydetails();
        }
        catch(invalidprice e){
            System.out.println(e.getMessage());
        }
        finally{
            System.out.println("product processing completed.");
        }
    }
}