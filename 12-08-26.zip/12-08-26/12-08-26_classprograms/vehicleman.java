abstract class Vehicle{
    abstract void start();
    void stop(){
        System.out.println("vehicle is stopping");
    }
}
class car extends Vehicle{
    void start(){
        System.out.println("car is starting");
    }
}
class bike extends Vehicle{
    void start(){
        System.out.println("bike is starting");
    }
}
class bus extends Vehicle{
    void start(){
        System.out.println("bus is starting");
    }
}
public class vehicleman {
    public static void main(String[] args){
        Vehicle v;
        v=new car();
        v.start();
        v.stop();
        v=new bike();
        v.start();
        v.stop();
        v=new bus();
        v.start();
        v.stop();
    }
}
