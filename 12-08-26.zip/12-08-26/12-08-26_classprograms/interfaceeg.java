interface Vehicle {
    void start();
    void stop();
    void run();
}

class Car implements Vehicle {

    public void start() {
        System.out.println("Car starts");
    }

    public void stop() {
        System.out.println("Car stops");
    }

    public void run() {
        System.out.println("Car is running");
    }
}

public class Interfaceeg {

    public static void main(String[] args) {

        Car c = new Car();

        c.start();
        c.run();
        c.stop();
    }
}