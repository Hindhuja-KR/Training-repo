interface Camera {

    void takePhoto();
}

interface MusicPlayer {

    void playMusic();
}
interface Gps{
    void trackLocation();
}

class Smartphone implements Camera, MusicPlayer {

    @Override
    public void takePhoto() {
        System.out.println("Smartphone takes a photo.");
    }

    @Override
    public void playMusic() {
        System.out.println("Smartphone plays music.");
    }

    public void makeCall() {
        System.out.println("Smartphone makes a call.");
    }
    public void trackLocation(){
        System.out.println("smartphone can track location");
    }
}

public class Multipleinterfaceeg{

    public static void main(String[] args) {

        Smartphone phone = new Smartphone();

        phone.takePhoto();
        phone.playMusic();
        phone.makeCall();
        phone.trackLocation();
    }
}