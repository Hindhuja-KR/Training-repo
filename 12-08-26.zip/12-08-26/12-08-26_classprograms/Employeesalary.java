abstract class Employee{
    int employeeid;
    String name;
    double salary;
    abstract double calculateFinalsalary();
    Employee(int employeeid, String name, double salary){
        this.employeeid=employeeid;
        this.name=name;
        this.salary=salary;
    }

    void displaySalary(){
        System.out.println("employee id:"+employeeid);
        System.out.println("employee name:"+name);
        System.out.println("salary :"+salary);
    }
    
}
class developer extends Employee{
    double bonus;
    developer(int employeeid, String name, double salary,double bonus){
        
        super(employeeid,name,salary);
        this.bonus=bonus;
    }
    double calculateFinalsalary(){
        return salary+bonus;
    }
}
class tester extends Employee{
    double allowance;
    tester(int employeeid, String name, double salary,double allowance){
        super(employeeid, name,salary);
        this.allowance=allowance;
    }
    double calculateFinalsalary(){
        return salary+allowance;
    }
}
public class Employeesalary {
    public static void main(String[] args){
        Employee e;
        e=new developer(102,"john",65000,2000);
        e.displaySalary();
        e=new tester(130,"madhu",34000,1500);
        e.displaySalary();
    }
}
