abstract class demo{
    abstract void absDisplay();
    
}
public class abstracteg extends demo{
    void absDisplay(){
        System.out.println(" ia m in main display");
    }
    public static void main(String [] args){
        demo d =new abstracteg();
        d.absDisplay();
    }
}