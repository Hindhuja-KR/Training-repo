abstract class Animal{
    abstract void sound();
    void eat(){
        System.out.println("animal is eating");
    }
       
}
class Dog extends Animal{
    void sound(){
        System.out.println("dog is barking");
    }
}
class Cat extends Animal{
    void sound(){
        System.out.println("cat is meowing");
    }
}
class Cow extends Animal{
    void sound(){
        System.out.println("cow is mooing");
    }
}

public class Animalsound {
   public static void main(String[] args){
        Dog d=new Dog();
        d.sound();
        Cat c=new Cat();
        c.sound();
        Cow o=new Cow();
        o.sound();
   } 
}
