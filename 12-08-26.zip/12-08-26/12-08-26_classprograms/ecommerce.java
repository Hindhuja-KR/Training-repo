abstract class product{
    int productid;
    String productname;
    double price;
    product(int productid, String pname, double price){
        this.productid=productid;
        this.productname=pname;
        this.price=price;
    }
    abstract double calculateDiscount();
    double calculateFinalprice(){
        return price-calculateDiscount();
    }
    void displayDetails(){
        System.out.println("product name:"+productname);
        System.out.println("product id :"+productid);
        System.out.println("price:"+price);
        System.out.println("discount :"+calculateDiscount());
        System.out.println("final price:"+calculateFinalprice());
    }
}
class electronics extends product{
    electronics(int productid, String pname, double price){
        super(productid,  pname,  price);
    }
    double calculateDiscount(){
        return price *10/100;
    }
}
class clothing extends product{
    clothing(int productid, String pname, double price){
        super( productid, pname, price);
    }
    double calculateDiscount(){
        return price *20/100;
    }
}
class grocery extends product{
    grocery(int productid, String pname, double price){
        super(productid, pname, price);
    }
    double calculateDiscount(){
        return price *5/100;
    }
}
public class ecommerce{
    public static void main(String[] args){
        product p;
        p=new electronics(12,"laptop",55000);
        p.displayDetails();
        p=new clothing(101,"anarkali",5400);
        p.displayDetails();
        p=new grocery(1102,"mushroom",50);
        p.displayDetails();

    }
}