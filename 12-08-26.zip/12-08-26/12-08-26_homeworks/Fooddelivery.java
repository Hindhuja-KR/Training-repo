abstract class Order {
    int orderId;
    String customerName;
    double amount;
    Order(int orderId, String customerName, double amount) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.amount = amount;
    }
    abstract double calculateDeliveryCharge();
    double calculateFinalBill() {
        return amount + calculateDeliveryCharge();
    }
    void displayDetails() {
        System.out.println("Order ID: " + orderId);
        System.out.println("Customer Name: " + customerName);
        System.out.println("Food Amount: " + amount);
        System.out.println("Delivery Charge: " + calculateDeliveryCharge());
        System.out.println("Final Bill: " + calculateFinalBill());
    }
}
class NormalDelivery extends Order {
    NormalDelivery(int orderId, String customerName, double amount) {
        super(orderId, customerName, amount);
    }
    double calculateDeliveryCharge() {
        return 40;
    }
}

class ExpressDelivery extends Order {
    ExpressDelivery(int orderId, String customerName, double amount) {
        super(orderId, customerName, amount);
    }
    double calculateDeliveryCharge() {
        return 80;
    }
}

public class Fooddelivery {
    public static void main(String[] args) {
        Order o;
        o = new NormalDelivery(101, "ritu", 500);
        o.displayDetails();
        System.out.println();
        o = new ExpressDelivery(102, "madu", 700);
        o.displayDetails();
    }
}
