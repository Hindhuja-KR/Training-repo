abstract class Account {
    int accountNumber;
    String accountHolderName;
    double balance;
    Account(int accountNumber, String accountHolderName, double balance) {
        this.accountNumber = accountNumber;
        this.accountHolderName = accountHolderName;
        this.balance = balance;
    }
    void deposit(double amount) {
        balance = balance + amount;
        System.out.println("deposited: " + amount);
    }
    abstract void withdraw(double amount);
    void displayBalance() {
        System.out.println("balance: " + balance);
    }
}
class SavingsAccount extends Account {
    double minimumBalance = 1000;
    SavingsAccount(int accountNumber, String accountHolderName, double balance) {
        super(accountNumber, accountHolderName, balance);
    }
    void withdraw(double amount) {
        if (balance - amount >= minimumBalance) {
            balance = balance - amount;
            System.out.println("withdrawal successful: " + amount);
        } else {
            System.out.println("withdrawal is failed ");
        }
    }
}
class CurrentAccount extends Account {
    double overdraftLimit = 5000;
    CurrentAccount(int accountNumber, String accountHolderName, double balance) {
        super(accountNumber, accountHolderName, balance);
    }
    void withdraw(double amount) {
        if (amount <= balance + overdraftLimit) {
            balance = balance - amount;
            System.out.println("withdrawal successful: " + amount);
        } else {
            System.out.println("withdraw failed limit exceeded");
        }
    }
}
public class Banking {
    public static void main(String[] args) {
        Account a;
        a = new SavingsAccount(101, "ritu", 10000);
        System.out.println("Savings Account");
        a.deposit(2000);
        a.withdraw(5000);
        a.displayBalance();
        System.out.println();
        a = new CurrentAccount(102, "madu", 10000);
        System.out.println("Current Account");
        a.deposit(2000);
        a.withdraw(14000);
        a.displayBalance();
    }
}