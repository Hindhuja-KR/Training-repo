abstract class ride {
    int rideid;
    String drivername;
    double distance;
    ride(int rideid, String drivername, double distance) {
        this.rideid = rideid;
        this.drivername = drivername;
        this.distance = distance;
    }
    abstract double calculatefare();
    void displaydetails() {
        System.out.println("Ride ID: " + rideid);
        System.out.println("Driver Name: " + drivername);
        System.out.println("Distance: " + distance + " km");
        System.out.println("Fare: " + calculatefare());
    }
}
class bike extends ride {
    bike(int rideid, String drivername, double distance) {
        super(rideid, drivername, distance);
    }
    double calculatefare() {
        return distance * 10;
    }
}
class auto extends ride {
    auto(int rideid, String drivername, double distance) {
        super(rideid, drivername, distance);
    }
    double calculatefare() {
        return distance * 15;
    }
}
class car extends ride {
    car(int rideid, String drivername, double distance) {
        super(rideid, drivername, distance);
    }
    double calculatefare() {
        return distance * 20;
    }
}
public class Ridebook {
    public static void main(String[] args) {
        ride r;
        r = new bike(101, "Arun", 10);
        r.displaydetails();
        r = new auto(102, "Kumar", 10);
        r.displaydetails();
        r = new car(103, "Ravi", 10);
        r.displaydetails();
    }
}