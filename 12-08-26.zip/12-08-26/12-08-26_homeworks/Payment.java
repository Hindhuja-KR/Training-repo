abstract class pay{
    abstract void makepayment();
}
class upi extends pay{
    void makepayment(){
        System.out.println("payment using upi");
    }
}
class creditcard extends pay{
    void makepayment(){
        System.out.println("payment using creditcard");
    }
}
class debitcard extends pay{
    void makepayment(){
        System.out.println("payment using debitcard");
    }
}
public class Payment {
    public static void main(String [] args){
        pay p;
        p=new upi();
        p.makepayment();
        p=new creditcard();
        p.makepayment();
        p=new debitcard();
        p.makepayment();
    }
}
