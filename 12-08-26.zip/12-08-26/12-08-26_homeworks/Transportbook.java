abstract class transport {
    String source;
    String destination;
    double basefare;
    transport(String source, String destination, double basefare) {
        this.source = source;
        this.destination = destination;
        this.basefare = basefare;
    }
    abstract double calculatefare();
    void displaydetails() {
        System.out.println("Source: " + source);
        System.out.println("Destination: " + destination);
        System.out.println("Base Fare: " + basefare);
        System.out.println("Final Fare: " + calculatefare());
    }
}
class bus extends transport {
    bus(String source, String destination, double basefare) {
        super(source, destination, basefare);
    }
    double calculatefare() {
        return basefare + 50;
    }
}
class train extends transport {
    train(String source, String destination, double basefare) {
        super(source, destination, basefare);
    }
    double calculatefare() {
        return basefare + 100;
    }
}
class flight extends transport {
    flight(String source, String destination, double basefare) {
        super(source, destination, basefare);
    }
    double calculatefare() {
        return basefare + 500;
    }
}
public class Transportbook {
    public static void main(String[] args) {
        transport t;
        t = new bus("Chennai", "Bangalore", 500);
        t.displaydetails();
        t = new train("Chennai", "Bangalore", 800);
        t.displaydetails();
        t = new flight("Chennai", "Bangalore", 3000);
        t.displaydetails();
    }
}