abstract class course {
    int courseid;
    String coursename;
    String instructor;
    double basefee;
    course(int courseid, String coursename, String instructor, double basefee) {
        this.courseid = courseid;
        this.coursename = coursename;
        this.instructor = instructor;
        this.basefee = basefee;
    }
    abstract double calculatefee();
    void displaydetails() {
        System.out.println("Course ID: " + courseid);
        System.out.println("Course Name: " + coursename);
        System.out.println("Instructor: " + instructor);
        System.out.println("Base Fee: " + basefee);
        System.out.println("Final Fee: " + calculatefee());
    }
}
class programming extends course {
    programming(int courseid, String coursename, String instructor, double basefee) {
        super(courseid, coursename, instructor, basefee);
    }
    double calculatefee() {
        return basefee + 500;
    }
}
class datasience extends course {
    datasience(int courseid, String coursename, String instructor, double basefee) {
        super(courseid, coursename, instructor, basefee);
    }
    double calculatefee() {
        return basefee + 1000;
    }
}
class cloud extends course {
    cloud(int courseid, String coursename, String instructor, double basefee) {
        super(courseid, coursename, instructor, basefee);
    }
    double calculatefee() {
        return basefee + 1500;
    }
}
public class Coursech {
    public static void main(String[] args) {
        course c;
        c = new programming(101, "Java Programming", "John", 5000);
        c.displaydetails();
        c = new datasience(102, "Data Science", "David", 6000);
        c.displaydetails();
        c = new cloud(103, "Cloud Computing", "Anu", 7000);
        c.displaydetails();
    }
}