abstract class Hospitalstaff {
    String name;
    int employeeId;
    String department;
    Hospitalstaff(String name, int employeeId, String department) {
        this.name = name;
        this.employeeId = employeeId;
        this.department = department;
    }
    abstract void performDuty();
    void displayDetails() {
        System.out.println("Name: " + name);
        System.out.println("Employee ID: " + employeeId);
        System.out.println("Department: " + department);
        performDuty();
    }
}
class Doctor extends Hospitalstaff {
    Doctor(String name, int employeeId, String department) {
        super(name, employeeId, department);
    }
    void performDuty() {
        System.out.println("treat patients");
    }
}
class Nurse extends Hospitalstaff {
    Nurse(String name, int employeeId, String department) {
        super(name, employeeId, department);
    }
    void performDuty() {
        System.out.println("take care of patients");
    }
}
class Pharmacist extends Hospitalstaff {
    Pharmacist(String name, int employeeId, String department) {
        super(name, employeeId, department);
    }
    void performDuty() {
        System.out.println("provide medicine");
    }
}
public class Hospital {
    public static void main(String[] args) {
        Hospitalstaff h;
        h = new Doctor("John", 101, "cardiology");
        h.displayDetails();
        System.out.println();
        h = new Nurse("Anu", 102, "Emergency");
        h.displayDetails();
        System.out.println();
        h = new Pharmacist("David", 103, "pharmacy");
        h.displayDetails();
    }
}