abstract class Shape{
    abstract double calculateArea();
}
class circle extends Shape{
    double radius;
    circle(double radius){
        this.radius=radius;
    }
    double calculateArea(){
        return 3.14*radius*radius;
    }
}
class rectangle extends Shape{
    double length;
    double breadth;
    rectangle(double length, double breadth){
        this.length=length;
        this.breadth=breadth;
    }
    double calculateArea(){
        return length*breadth;
    }
}
class triangle extends Shape{
    double base;
    double height;
    triangle(double base, double height){
        this.base=base;
        this.height=height;
    }
    double calculateArea(){
        return 0.5*base*height;
    }
}
public class Shapearea {
    public static void main(String[] args){
        Shape s;
        s=new circle(5);
        System.out.println("area of circle:"+s.calculateArea());
        s=new rectangle(10,20);
        System.out.println("area of rectangle"+s.calculateArea());
        s=new triangle(5,5);
        System.out.println("area of triangle:"+s.calculateArea());
    }
}
