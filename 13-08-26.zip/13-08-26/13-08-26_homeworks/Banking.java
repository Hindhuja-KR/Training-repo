class invalidamount extends Exception {
    invalidamount(String msg) {
        super(msg);
    }
}
abstract class bankaccount {
    private int accountnumber;
    private String accountholdername;
    private double balance;
    bankaccount(int accountnumber, String accountholdername, double balance) {
        this.accountnumber = accountnumber;
        this.accountholdername = accountholdername;
        this.balance = balance;
    }
    int getaccountnumber() {
        return accountnumber;
    }
    String getaccountholdername() {
        return accountholdername;
    }
    double getbalance() {
        return balance;
    }
    void deposit(double amount) throws invalidamount {
        if (amount <= 0) {
            throw new invalidamount("Invalid deposit amount");
        }
        balance = balance + amount;
        System.out.println("Amount deposited: " + amount);
    }
    void reducebalance(double amount) {
        balance = balance - amount;
    }
    abstract void withdraw(double amount) throws invalidamount;
}
class savingsaccount extends bankaccount {
    savingsaccount(int accountnumber, String accountholdername, double balance) {
        super(accountnumber, accountholdername, balance);
    }
    void withdraw(double amount) throws invalidamount {
        if (amount <= 0) {
            throw new invalidamount("Invalid withdrawal amount");
        }
        if (amount > getbalance()) {
            throw new invalidamount("Insufficient balance");
        }
        reducebalance(amount);
        System.out.println("Savings withdrawal successful: " + amount);
    }
}
class currentaccount extends bankaccount {
    double minimumbalance = 1000;
    currentaccount(int accountnumber, String accountholdername, double balance) {
        super(accountnumber, accountholdername, balance);
    }
    void withdraw(double amount) throws invalidamount {
        if (amount <= 0) {
            throw new invalidamount("Invalid withdrawal amount");
        }
        if (getbalance() - amount < minimumbalance) {
            throw new invalidamount("Minimum balance must be maintained");
        }
        reducebalance(amount);
        System.out.println("Current withdrawal successful: " + amount);
    }
}
public class Banking {
    public static void main(String[] args) {
        bankaccount b;
        try {
            b = new savingsaccount(101, "Hindhuja", 10000);
            b.deposit(2000);
            b.withdraw(3000);
            System.out.println("Savings balance: " + b.getbalance());
            b = new currentaccount(102, "Rajesh", 15000);
            b.deposit(3000);
            b.withdraw(5000);
            System.out.println("Current balance: " + b.getbalance());
            b.withdraw(20000);
        } catch (invalidamount e) {
            System.out.println(e.getMessage());
        } finally {
            System.out.println("Bank transaction completed.");
        }
    }
}