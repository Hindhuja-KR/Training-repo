class invalidsalary extends Exception{
    invalidsalary(String msg){
        super(msg);
    }
}
abstract class employee{
    private int employeeid;
    private String employeename;
    private double basicsalary;
    employee(int employeeid,String employeename,double basicsalary)throws invalidsalary{
        if(basicsalary<=0){
            throw new invalidsalary("invalid salary");
        }
        this.employeeid=employeeid;
        this.employeename=employeename;
        this.basicsalary=basicsalary;
    }
    int getemployeeid(){
        return employeeid;
    }
    String getemployeename(){
        return employeename;
    }
    double getbasicsalary(){
        return basicsalary;
    }
    abstract double calculatesalary();
    abstract double calculateallowance();
    void displaydetails(){
        System.out.println("employee id:"+employeeid);
        System.out.println("employee name:"+employeename);
        System.out.println("basic salary:"+basicsalary);
        System.out.println("allowance:"+calculateallowance());
        System.out.println("final salary:"+calculatesalary());
    }
}
class fulltimeemployee extends employee{
    fulltimeemployee(int employeeid,String employeename,double basicsalary)throws invalidsalary{
        super(employeeid,employeename,basicsalary);
    }
    double calculateallowance(){
        return getbasicsalary()*20/100;
    }
    double calculatesalary(){
        return getbasicsalary()+calculateallowance();
    }
}

class parttimeemployee extends employee{
    parttimeemployee(int employeeid,String employeename,double basicsalary)throws invalidsalary{
        super(employeeid,employeename,basicsalary);
    }
    double calculateallowance(){
        return getbasicsalary()*10/100;
    }
    double calculatesalary(){
        return getbasicsalary()+calculateallowance();
    }
}
class contractemployee extends employee{
    contractemployee(int employeeid,String employeename,double basicsalary)throws invalidsalary{
        super(employeeid,employeename,basicsalary);
    }
    double calculateallowance(){
        return getbasicsalary()*5/100;
    }
    double calculatesalary(){
        return getbasicsalary()+calculateallowance();
    }
}
public class Employee{
    public static void main(String[] args){
        employee e;
        try{
            e=new fulltimeemployee(101,"arun",50000);
            e.displaydetails();
            e=new parttimeemployee(102,"kumar",30000);
            e.displaydetails();
             e=new contractemployee(103,"ravi",40000);
            e.displaydetails();
        }
        catch(invalidsalary ex){
            System.out.println(ex.getMessage());
        }
        finally{
            System.out.println("payroll completed");
        }
    }
}