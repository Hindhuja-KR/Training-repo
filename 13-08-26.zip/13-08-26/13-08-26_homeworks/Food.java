class invalidorder extends Exception{
    invalidorder(String msg){
        super(msg);
    }
}
abstract class foodorder{
    private int orderid;
    private String customername;
    private String foodname;
    private double price;
    private int quantity;
    foodorder(int orderid,String customername,String foodname,double price,int quantity)throws invalidorder{
        if(price<=0){
            throw new invalidorder("invalid price");
        }
        if(quantity<=0){
            throw new invalidorder("invalid quantity");
        }
        this.orderid=orderid;
        this.customername=customername;
        this.foodname=foodname;
        this.price=price;
        this.quantity=quantity;
    }
    int getorderid(){
        return orderid;
    }
    String getcustomername(){
        return customername;
    }
    String getfoodname(){
        return foodname;
    }
    double getprice(){
        return price;
    }
    int getquantity(){
        return quantity;
    }

    double calculatefoodcost(){
        return price*quantity;
    }
    abstract double calculatedeliverycharge();
    double calculatefinalbill(){
        return calculatefoodcost()+calculatedeliverycharge();
    }
    void displaydetails(){
        System.out.println("order id:"+orderid);
        System.out.println("customer name:"+customername);
        System.out.println("food name:"+foodname);
        System.out.println("price:"+price);
        System.out.println("quantity:"+quantity);
        System.out.println("food cost:"+calculatefoodcost());
        System.out.println("delivery charge:"+calculatedeliverycharge());
        System.out.println("final bill:"+calculatefinalbill());
    }
}
class restaurantorder extends foodorder{
    restaurantorder(int orderid,String customername,String foodname,double price,int quantity)throws invalidorder{
        super(orderid,customername,foodname,price,quantity);
    }
    double calculatedeliverycharge(){
        return 50;
    }
}
class fastfoodorder extends foodorder{
    fastfoodorder(int orderid,String customername,String foodname,double price,int quantity)throws invalidorder{
        super(orderid,customername,foodname,price,quantity);
    }
    double calculatedeliverycharge(){
        return 30;
    }
}
class premiumorder extends foodorder{
    premiumorder(int orderid,String customername,String foodname,double price,int quantity)throws invalidorder{
        super(orderid,customername,foodname,price,quantity);
    }
    double calculatedeliverycharge(){
        return 0;
    }
}
public class Food
{
    public static void main(String[] args){
        foodorder f;
        try{
            f=new restaurantorder(101,"anu","biryani",250,2);
            f.displaydetails();
            f=new fastfoodorder(102,"ravi","burger",150,3);
            f.displaydetails();
            f=new premiumorder(103,"kumar","pizza",500,2);
            f.displaydetails();
        }
        catch(invalidorder e){
            System.out.println(e.getMessage());
        }
        finally{
            System.out.println("food order completed");
        }
    }
}