class invalidprice extends Exception {
    invalidprice(String msg) {
        super(msg);
    }
}
abstract class product {
    private int productid;
    private String productname;
    private double price;
    product(int productid, String productname, double price) throws invalidprice {
        if (price <= 0) {
            throw new invalidprice("Product price must be greater than zero");
        }
        this.productid = productid;
        this.productname = productname;
        this.price = price;
    }
    int getproductid() {
        return productid;
    }
    String getproductname() {
        return productname;
    }
    double getprice() {
        return price;
    }
    abstract double calculatediscount();
    double calculatefinalprice() {
        return price - calculatediscount();
    }
    void displaydetails() {
        System.out.println("Product ID: " + productid);
        System.out.println("Product Name: " + productname);
        System.out.println("Original Price: " + price);
        System.out.println("Discount Amount: " + calculatediscount());
        System.out.println("Final Price: " + calculatefinalprice());
    }
}
class electronics extends product {
    electronics(int productid, String productname, double price) throws invalidprice {
        super(productid, productname, price);
    }
    double calculatediscount() {
        return getprice() * 10 / 100;
    }
}
class clothing extends product {
    clothing(int productid, String productname, double price) throws invalidprice {
        super(productid, productname, price);
    }
    double calculatediscount() {
        return getprice() * 20 / 100;
    }
}
class grocery extends product {
    grocery(int productid, String productname, double price) throws invalidprice {
        super(productid, productname, price);
    }
    double calculatediscount() {
        return getprice() * 5 / 100;
    }
}
public class Onlineshop {
    public static void main(String[] args) {
        product p;
        try {
            p = new electronics(101, "Laptop", 50000);
            p.displaydetails();
            p = new clothing(102, "Shirt", 2000);
            p.displaydetails();
            p = new grocery(103, "Rice", 1000);
            p.displaydetails();
            p = new electronics(104, "Mobile", -5000);
        } catch (invalidprice e) {
            System.out.println(e.getMessage());
        } finally {
            System.out.println("Product processing completed.");
        }
    }
}