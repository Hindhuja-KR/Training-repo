class invalidpatient extends Exception{
    invalidpatient(String msg){
        super(msg);
    }
}
abstract class patient{
    private int patientid;
    private String patientname;
    private int age;
    private double consultationfee;
    patient(int patientid,String patientname,int age,double consultationfee)throws invalidpatient{
        if(age<=0){
            throw new invalidpatient("invalid age");
        }
        if(consultationfee<=0){
            throw new invalidpatient("invalid consultation fee");
        }
        this.patientid=patientid;
        this.patientname=patientname;
        this.age=age;
        this.consultationfee=consultationfee;
    }
    int getpatientid(){
        return patientid;
    }
    String getpatientname(){
        return patientname;
    }
    int getage(){
        return age;
    }
    double getconsultationfee(){
        return consultationfee;
    }
    abstract double calculatebill();
    void displaydetails(){
        System.out.println("patient id:"+patientid);
        System.out.println("patient name:"+patientname);
        System.out.println("age:"+age);
        System.out.println("consultation fee:"+consultationfee);
        System.out.println("final bill:"+calculatebill());
    }
}
class generalpatient extends patient{
    generalpatient(int patientid,String patientname,int age,double consultationfee)throws invalidpatient{
        super(patientid,patientname,age,consultationfee);
    }
    double calculatebill(){
        return getconsultationfee();
    }
}
class emergencypatient extends patient{
    emergencypatient(int patientid,String patientname,int age,double consultationfee)throws invalidpatient{
        super(patientid,patientname,age,consultationfee);
    }
    double calculatebill(){
        return getconsultationfee()+getconsultationfee()*30/100;
    }
}
class insurancepatient extends patient{
    insurancepatient(int patientid,String patientname,int age,double consultationfee)throws invalidpatient{
        super(patientid,patientname,age,consultationfee);
    }
    double calculatebill(){
        return getconsultationfee()-getconsultationfee()*20/100;
    }
}
public class Hospital{
    public static void main(String[] args){
        patient p;
        try{
            p=new generalpatient(101,"anu",25,500);
            p.displaydetails();
            p=new emergencypatient(102,"ravi",40,1000);
            p.displaydetails();
            p=new insurancepatient(103,"kumar",35,2000);
            p.displaydetails();
        }
        catch(invalidpatient e){
            System.out.println(e.getMessage());
        }
        finally{
            System.out.println("patient billing completed");
        }
    }
}