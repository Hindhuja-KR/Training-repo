class Student{
    private int age;
    private String name;
    Student(String name, int age){
        this.name=name;
        this.age=age;
    }
    public String getname(){
        return name;
    }
    public int getage(){
        return age;
    }
    
    // the below one is getter and setter methods 
    // public void setname(String name){
    //     this.name=name;
    // }
    // public String getname(){
    //     return name;
    // }
    // public void setage(int age ){
    //     this.age=age;
    // }
    // public int getage(){
    //     return age;
    // }
}
public class Encaps{
    public static void main(String[] args){
        Student s=new Student("madhu",10);
        // s.setname("madhu");
        // System.out.println("student name:"+s.getname());
        // s.setage(10);
        // System.out.println("student age:"+s.getage());
        System.out.println("name:"+s.getname());
        System.out.println("age:"+s.getage());
    }
}