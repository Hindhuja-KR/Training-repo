class Account{
    static String bankname="Mariamman Indian Bank";
    private int accnum;
    private String accholdername;
    private int mobile;
    private String acctype;
    private double balance;

    Account(int accnum, String accholdername, int mobile,String acctype, double balance){
        this.accnum=accnum;
        this.accholdername=accholdername;
        this.mobile=mobile;
        this.acctype=acctype;
        this.balance=balance;
    }
    public int getaccountnumber(){
        return accnum;
    }
    public String getaccholdername(){
        return accholdername;
    }
    public int getmobilenum(){
        return mobile;
    }
    public String getacctype(){
        return acctype;
    }
    public double getbalance(){
        return balance;
    }
    public double deposit(double amount){
        if(amount<=0){
            System.out.println("invalid deposit amount");
        }
        balance+=amount;
        return balance;
    }
    public double withdraw(double amount){
        if(amount<=0){
            System.out.println("invalid withdrawl amount");
        }
        else if(amount>balance){
            System.out.println("Insufficient balance");
        }
        balance-=amount;
        return balance;
    }
    public void setmobilenum(int mobile){
        this.mobile=mobile;
    }
    public void displayAccountdetails(){
        System.out.println("bank name:"+bankname);
        System.out.println("account number:"+getaccountnumber());
        System.out.println("acc holder name:"+getaccholdername());
        System.out.println("mobile number:"+getmobilenum());
        System.out.println("acctype :"+getacctype());
        System.out.println("balnace:"+getbalance());
        
    }
    
}
public class Accountencaps {
    public static void main(String[] args){
        Account a=new Account(1001,"arun",989898767,"savings",25000);
        Account b=new Account(1002,"kumar",879878765,"current",50000);
        a.displayAccountdetails();
        a.deposit(3000);
        a.withdraw(1000);
        a.getmobilenum();
        a.deposit(-200);
        a.withdraw(0);
        a.withdraw(90000);
        b.displayAccountdetails();
        b.deposit(10000);
        b.withdraw(5000);
        b.displayAccountdetails();
    }
}
